from django.apps import AppConfig


class BeltQuotesConfig(AppConfig):
    name = 'belt_quotes'
